# pip install pyzmq cbor keyboard
#from zmqRemoteApi import RemoteAPIClient
from zmqRemoteApi_IPv6 import RemoteAPIClient
import keyboard

client = RemoteAPIClient('127.0.0.1', 23000)

print('Program started')
sim = client.getObject('sim')



sim.startSimulation()
print('Simulation started')

def setBubbleRobVelocity(leftWheelVelocity, rightWheelVelocity,DE,DR):
    leftMotor2 = sim.getObject('/jointl2333')
    rightMotor2 = sim.getObject('/jointr2333')
    leftMotor = sim.getObject('/jointl1222')
    rightMotor = sim.getObject('/jointr1222')
    sim.setJointTargetVelocity(leftMotor, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor, rightWheelVelocity)
    sim.setJointTargetVelocity(leftMotor2, DE)
    sim.setJointTargetVelocity(rightMotor2, DR)
  
'''
# Example usage 1:
setBubbleRobVelocity(1.0, 1.0,1,1)
time.sleep(2)
setBubbleRobVelocity(0.0,0,0, 0.0)
'''
# use keyborad to move BubbleRob

while True:
    if keyboard.is_pressed('up'):
        setBubbleRobVelocity(-10, -10.0,-10, -10)
    elif keyboard.is_pressed('down'):
        setBubbleRobVelocity(10.0, 10.0,10,10)
    elif keyboard.is_pressed('left'):
        setBubbleRobVelocity(10.0, -10.0,0,0)
    elif keyboard.is_pressed('right'):
        setBubbleRobVelocity(-10.0, 10.0,0,0)
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
    else:
        setBubbleRobVelocity(0.0, 0.0,0,0)




